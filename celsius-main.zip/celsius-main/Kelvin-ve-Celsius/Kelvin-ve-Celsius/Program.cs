﻿using Kelvin_ve_Celsius;
Kelvin kelvin = new()
{
    degree = 0
};
Celsius celsius = kelvin;
Console.WriteLine(celsius.degree);
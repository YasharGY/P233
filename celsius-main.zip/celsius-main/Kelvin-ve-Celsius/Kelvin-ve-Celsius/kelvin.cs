﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kelvin_ve_Celsius;

public class Kelvin
{
    public int degree { get; set; }
}
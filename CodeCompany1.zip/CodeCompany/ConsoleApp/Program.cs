﻿using CodeCompany.Core.Entities;
using CodeCompanyInfrastucture.DBContext;
using CodeCompanyInfrastucture.Services;
using System;
using System.Data;

namespace CompanyConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            CompanyService companyService = new CompanyService();
            while (true)
            {
                Console.WriteLine("\nSelect the option:");
                Console.WriteLine("0: Exit");
                Console.WriteLine("1: Create a new company");
                Console.WriteLine("2: Display all companies");

                string? response = Console.ReadLine();
                int menu;
                bool tryToInt = int.TryParse(response, out menu);
                if (tryToInt)
                {
                    switch (menu)
                    {
                        case 0:
                            Environment.Exit(0);
                            break;
                        case 1:
                            Console.WriteLine("Enter Company Name:");
                            try
                            {
                                string? res_companyname = Console.ReadLine();
                                companyService.Create(res_companyname);
                                Console.WriteLine($"New company is created: {res_companyname}");
                            }
                            catch (ArgumentNullException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            catch (DuplicateNameException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;
                        case 2:
                            Console.WriteLine("Companies List:");
                            companyService.GetAll();
                            break;
                        default:
                            Console.WriteLine("Select correct ones from menu!!!");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Enter correct menu item");
                }
            }
        }
    }
}
